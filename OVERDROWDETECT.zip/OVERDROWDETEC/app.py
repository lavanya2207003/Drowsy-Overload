import cv2
import dlib
from scipy.spatial import distance

# ------------------ Aspect Ratio Calculations ------------------

def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])
    return (A + B) / (2.0 * C)

def mouth_aspect_ratio(mouth):
    A = distance.euclidean(mouth[3], mouth[7])  # 64-68
    B = distance.euclidean(mouth[2], mouth[6])  # 63-67
    C = distance.euclidean(mouth[0], mouth[4])  # 61-65
    return (A + B) / (2.0 * C)

# ------------------ Thresholds & Counters ------------------

EAR_THRESHOLD = 0.25          # Eye aspect ratio threshold
EAR_CONSEC_FRAMES = 20        # Frames to trigger drowsiness alert
MAR_THRESHOLD = 0.6           # Mouth aspect ratio threshold
YAWN_CONSEC_FRAMES = 15       # Frames to trigger yawn alert

eye_counter = 0
yawn_counter = 0
alarm_on = False
yawn_alert = False

# ------------------ Load dlib face detector & predictor ------------------

print("[INFO] Loading shape predictor...")
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# ------------------ Landmark Indexes ------------------

LEFT_EYE = list(range(36, 42))
RIGHT_EYE = list(range(42, 48))
MOUTH = list(range(60, 68))

# ------------------ Start Webcam ------------------

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)

    for face in faces:
        shape = predictor(gray, face)
        shape = [(shape.part(i).x, shape.part(i).y) for i in range(68)]

        # Eyes
        left_eye = [shape[i] for i in LEFT_EYE]
        right_eye = [shape[i] for i in RIGHT_EYE]
        ear = (eye_aspect_ratio(left_eye) + eye_aspect_ratio(right_eye)) / 2.0

        # Mouth
        mouth = [shape[i] for i in MOUTH]
        mar = mouth_aspect_ratio(mouth)

        # ------------------ Drowsiness Detection ------------------
        if ear < EAR_THRESHOLD:
            eye_counter += 1
            if eye_counter >= EAR_CONSEC_FRAMES:
                alarm_on = True
                cv2.putText(frame, "DROWSINESS ALERT!", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)
        else:
            eye_counter = 0
            alarm_on = False

        # ------------------ Yawn Detection ------------------
        if mar > MAR_THRESHOLD:
            yawn_counter += 1
            if yawn_counter >= YAWN_CONSEC_FRAMES:
                yawn_alert = True
                cv2.putText(frame, "YAWNING ALERT!", (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)
        else:
            yawn_counter = 0
            yawn_alert = False

        # Draw eye contours
        for eye in [left_eye, right_eye]:
            for i in range(len(eye)):
                pt1 = eye[i]
                pt2 = eye[(i + 1) % len(eye)]
                cv2.line(frame, pt1, pt2, (0, 255, 0), 1)

        # Draw mouth contour
        for i in range(len(mouth)):
            pt1 = mouth[i]
            pt2 = mouth[(i + 1) % len(mouth)]
            cv2.line(frame, pt1, pt2, (255, 0, 0), 1)

    # Display the frame
    cv2.imshow("Driver Monitoring", frame)
    if cv2.waitKey(1) & 0xFF == 27:  # Press ESC to quit
        break

cap.release()
cv2.destroyAllWindows()
