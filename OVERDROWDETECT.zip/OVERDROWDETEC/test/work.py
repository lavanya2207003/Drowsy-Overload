import streamlit as st
import requests
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from auth import login_page, register_page, logout

# Handle Authentication
query_params = st.experimental_get_query_params()
current_page = query_params.get("page", ["login"])[0]
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""
if not st.session_state.logged_in:
    if current_page == "register":
        register_page()
    else:
        login_page()
    st.stop()

# Logout button
st.sidebar.button("Logout", on_click=logout)

# Set background image function
def set_background(image_url):
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("{image_url}");
            background-size: cover;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

# Set background for the main page
set_background("https://static.vecteezy.com/system/resources/thumbnails/029/754/480/small/yellow-plastic-concrete-mixer-truck-toy-isolated-on-ink-background-construction-vechicle-truck-with-copy-space-for-banner-of-toy-store-photo.jpg")

def infer_image(image):
    api_url = "https://detect.roboflow.com/overloaded-detection/2"
    api_key = "BcxH1UJwEpSYxgbCu3HI"

    image = image.convert("RGB")
    image_np = np.array(image)
    _, img_encoded = cv2.imencode(".jpg", cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR))
    response = requests.post(
        f"{api_url}?api_key={api_key}",
        files={"file": img_encoded.tobytes()}
    )

    if response.status_code == 200:
        return response.json()
    return None

# Function to draw bounding boxes
def draw_boxes(image, detections):
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()

    for det in detections:
        x, y, w, h = det['x'], det['y'], det['width'], det['height']
        left = x - w / 2
        top = y - h / 2
        right = x + w / 2
        bottom = y + h / 2
        label = f"{det['class']} ({det['confidence']*100:.1f}%)"

        draw.rectangle([left, top, right, bottom], outline="red", width=3)

        # Get text size using textbbox
        text_bbox = draw.textbbox((left, top), label, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]

        # Draw background rectangle for text
        draw.rectangle([left, top - text_height, left + text_width, top], fill="red")
        draw.text((left, top - text_height), label, fill="white", font=font)

    return image


def main():
    st.title("Object Detection")

    uploaded_file = st.file_uploader("Upload an image", type=["jpg", "png", "jpeg"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)

        if st.button("Detect Objects"):
            detections = infer_image(image)
            if detections:
                detected_objects = detections.get("predictions", [])

                if detected_objects:
                    st.write("Detected Objects:")
                    for detection in detected_objects:
                        st.write(f"- {detection['class']} (Confidence: {detection['confidence']*100:.2f}%)")

                    # Draw boxes and show updated image
                    image_with_boxes = draw_boxes(image.copy(), detected_objects)
                    st.image(image_with_boxes, caption="Detection Result", use_column_width=True)
                else:
                    st.warning("No objects detected.")
            else:
                st.error("Detection failed. Please try again.")

if __name__ == "__main__":
    main()
