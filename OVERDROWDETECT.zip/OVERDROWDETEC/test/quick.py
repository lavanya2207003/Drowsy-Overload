import streamlit as st
import requests
import cv2
import numpy as np
from PIL import Image, ImageDraw
from twilio.rest import Client
from auth import login_page, register_page, logout

# Handle Authentication
query_params = st.experimental_get_query_params()
current_page = query_params.get("page", ["login"])[0]
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""
if not st.session_state.logged_in:
    if current_page == "register":
        register_page()
    else:
        login_page()
    st.stop()

# Logout button
st.sidebar.button("Logout", on_click=logout)

# Set background image function
def set_background(image_url):
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("{image_url}");
            background-size: cover;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

# Set background for the main page
set_background("https://static.vecteezy.com/system/resources/thumbnails/029/754/480/small/yellow-plastic-concrete-mixer-truck-toy-isolated-on-ink-background-construction-vechicle-truck-with-copy-space-for-banner-of-toy-store-photo.jpg")
# Twilio Configuration
TWILIO_ACCOUNT_SID = "ACf31d1d1e4474aa2dc346917927735aff"
TWILIO_AUTH_TOKEN = "22be341ddbf9c0c12078e01e5eadc267"
TWILIO_PHONE_NUMBER = "+15706781739"
TO_PHONE_NUMBER = "+919360876883"

# Get real-time location using JavaScript
def get_location():
    """Uses JavaScript to get the user's current location."""
    location_script = """
    <script>
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                document.getElementById("lat").value = latitude;
                document.getElementById("lon").value = longitude;
            }
        );
    </script>
    <input type="hidden" id="lat" name="lat">
    <input type="hidden" id="lon" name="lon">
    """
    st.components.v1.html(location_script)
    lat = st.text_input("Latitude", key="lat")
    lon = st.text_input("Longitude", key="lon")

    if lat and lon:
        return float(lat), float(lon)
    return None, None

def send_sms_notification(detected_objects, lat, lon):
    """Send an SMS notification with location using Twilio."""
    client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

    location_link = f"https://www.google.com/maps?q={lat},{lon}" if lat and lon else "Location not available"

    message_body = "🚨 Object Detection Alert!\nDetected objects:\n"
    for obj in detected_objects:
        message_body += f"- {obj['class']} (Confidence: {obj['confidence']*100:.2f}%)\n"

    message_body += f"\n📍 Location: {location_link}"

    message = client.messages.create(
        body=message_body,
        from_=TWILIO_PHONE_NUMBER,
        to=TO_PHONE_NUMBER
    )

    return message.sid

def infer_image(image):
    api_url = "https://detect.roboflow.com/overloaded-detection/2"
    api_key = "BcxH1UJwEpSYxgbCu3HI"

    image = image.convert("RGB")
    image_np = np.array(image)
    _, img_encoded = cv2.imencode(".jpg", cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR))
    response = requests.post(
        f"{api_url}?api_key={api_key}",
        files={"file": img_encoded.tobytes()}
    )

    if response.status_code == 200:
        return response.json()
    return None

def main():
    st.title("Object Detection with Location & Twilio Alerts")
    
    # Fetch user location
    lat, lon = get_location()
    
    uploaded_file = st.file_uploader("Upload an image", type=["jpg", "png", "jpeg"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)

        if st.button("Detect Objects"):
            detections = infer_image(image)
            if detections:
                detected_objects = detections.get("predictions", [])

                if detected_objects:
                    st.write("Detected Objects:")
                    for detection in detected_objects:
                        st.write(f"- {detection['class']} (Confidence: {detection['confidence']*100:.2f}%)")

                    if lat and lon:
                        message_id = send_sms_notification(detected_objects, lat, lon)
                        st.success(f"Notification Sent! Message ID: {message_id}")
                    else:
                        st.warning("Could not fetch location. Please allow location access.")

                else:
                    st.warning("No objects detected.")
            else:
                st.error("Detection failed. Please try again.")

if __name__ == "__main__":
    main()
