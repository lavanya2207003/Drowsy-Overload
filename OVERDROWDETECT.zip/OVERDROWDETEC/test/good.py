import streamlit as st
import requests
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import subprocess
from auth import login_page, register_page, logout
from streamlit_webrtc import webrtc_streamer, VideoTransformerBase
import av

# --- Authentication ---
query_params = st.experimental_get_query_params()
current_page = query_params.get("page", ["login"])[0]
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""
if not st.session_state.logged_in:
    if current_page == "register":
        register_page()
    else:
        login_page()
    st.stop()

st.sidebar.button("Logout", on_click=logout)

# --- Background Image ---
def set_background(image_url):
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("{image_url}");
            background-size: cover;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

set_background("https://static.vecteezy.com/system/resources/thumbnails/029/754/480/small/yellow-plastic-concrete-mixer-truck-toy-isolated-on-ink-background-construction-vechicle-truck-with-copy-space-for-banner-of-toy-store-photo.jpg")

# --- Object Detection Function ---
def infer_image(image):
    api_url = "https://detect.roboflow.com/overloaded-detection/2"
    api_key = "BcxH1UJwEpSYxgbCu3HI"
    image = image.convert("RGB")
    image_np = np.array(image)
    _, img_encoded = cv2.imencode(".jpg", cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR))
    response = requests.post(
        f"{api_url}?api_key={api_key}",
        files={"file": img_encoded.tobytes()}
    )
    if response.status_code == 200:
        return response.json()
    return None

# --- Draw Bounding Boxes ---
def draw_boxes(image, detections):
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default()
    for det in detections:
        x, y, w, h = det['x'], det['y'], det['width'], det['height']
        left = x - w / 2
        top = y - h / 2
        right = x + w / 2
        bottom = y + h / 2
        label = f"{det['class']} ({det['confidence']*100:.1f}%)"
        draw.rectangle([left, top, right, bottom], outline="red", width=3)
        text_bbox = draw.textbbox((left, top), label, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        draw.rectangle([left, top - text_height, left + text_width, top], fill="red")
        draw.text((left, top - text_height), label, fill="white", font=font)
    return image

# --- Streamlit Tabs ---
tab1, tab2 = st.tabs(["🚚 Real-Time Object Detection", "😴 Drowsiness Detection"])

# --- Tab 1: Real-Time Object Detection ---
with tab1:
    st.title("Real-Time Object Detection")

    class ObjectDetectionTransformer(VideoTransformerBase):
        def transform(self, frame):
            image = frame.to_ndarray(format="bgr24")
            image_pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            detections = infer_image(image_pil)
            if detections:
                detected_objects = detections.get("predictions", [])
                image_pil = draw_boxes(image_pil, detected_objects)
            result_image = cv2.cvtColor(np.array(image_pil), cv2.COLOR_RGB2BGR)
            return result_image

    st.info("Allow camera access and wait for detection results.")
    webrtc_streamer(
        key="object-detection",
        video_transformer_factory=ObjectDetectionTransformer,
        media_stream_constraints={"video": True, "audio": False}
    )

# --- Tab 2: Drowsiness Detection ---
with tab2:
    st.title("Drowsiness Detection")
    st.info("Click below to start real-time drowsiness detection in a new window.")
    if st.button("Start Drowsiness Detection"):
        subprocess.Popen(["python", "drowsiness_detection.py"])
        st.success("Drowsiness detection started in a new window.")
